'use strict';

import { AgentsMockData } from "./agents.mock.data";

module.exports.handler = async (event) => {
  console.log(event)
  id = 101
  record = AgentsMockData.filter(agent=> agent._id = id)[0]
  return {
    statusCode: 200,
    body: JSON.stringify(record),
  };
};
