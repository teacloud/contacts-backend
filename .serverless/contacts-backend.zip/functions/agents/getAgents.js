'use strict';

import { AgentsMockData } from "./agents.mock.data";

module.exports.handler = async (event) => {
  return {
    statusCode: 200,
    body: JSON.stringify(AgentsMockData),
  };
};
