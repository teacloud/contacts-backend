'use strict';

import { AgentsMockData } from "./agents.mock.data";

module.exports.handler = async (event) => {
    console.log(event)
    id = 101
    updatedRecord = {}
    record = AgentsMockData.map(agent => {
        if (agent.id = id) {
            
        }
    })
    return {
        statusCode: 200,
        body: JSON.stringify(record),
    };
};
