export const AgentsMockData = [
    {
        "_id": 101, 
        "name": "John Doe",
        "address": "123 Main Street #200",
        "city": "Seattle",
        "state": "WA",
        "zipCode": "98101",
        "tier": 2,
        "phone":{
            "primary": "206-221-2345",
            "mobile": "206-555-3211"
        }
    },
    {
        "_id": 321, 
        "name": "Abe Simpson",
        "address": "2445 Onion Belt Ave",
        "city": "Springfield",
        "state": "IL",
        "zipCode": "62701",
        "tier": 1,
        "phone":{
            "primary": "217-345-2345",
            "mobile": "217-987-3211"
        }
    },
    {
        "_id": 467, 
        "name": "Joseph Schmoe",
        "address": "2765 There Street",
        "city": "Charlotte",
        "state": "NC",
        "zipCode": "28205",
        "tier": 3,
        "phone":{
            "primary": "828-865-2345",
            "mobile": "828-432-3211"
        }
    },
    {
        "_id": 1987, 
        "name": "Bob Loblaw",
        "address": "123 Main Street #200",
        "city": "Laguna Beach",
        "state": "CA",
        "zipCode": "92677",
        "tier": 2,
        "phone":{
            "primary": "714-765-2349",
            "mobile": "714-496-3288"
        }
    }
]